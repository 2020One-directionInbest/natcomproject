<?php
include_once('dp.php');
if(isset($_POST['submit'])){
    $f=$_POST['ID'];
$a=$_POST['username'];
$b=$_POST['password'];

$d=$_POST['usertype'];

$q="INSERT INTO `user`(`id`, `username`, `password`, `usertype`) VALUES ('$f','$a','$b','$d')";
$con->exec($q);
echo"<script>alert('created Successfully!')</script>";
echo"<script>window.location='index.php'</script>";
}

?>