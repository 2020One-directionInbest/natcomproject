<?php
include_once('dp.php');
if(isset($_POST['submit'])){
    $f=$_POST['id'];
$a=$_POST['name'];
$b=$_POST['lname'];
$c=$_POST['Gender'];
$d=$_POST['Telephone'];
$e=$_POST['Address'];
$q="INSERT INTO `trainees`(`traineesid`, `fname`, `lname`, `gender`, `phone`, `address`) VALUES ('$f','$a','$b','$c','$d','$e')";
$con->exec($q);
echo"<script>alert('created Successfully!')</script>";
echo"<script>window.location='index2.php'</script>";
}
?>