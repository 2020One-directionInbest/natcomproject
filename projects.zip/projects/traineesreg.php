
<html>


<head>
    <title>
        Form
    </title>
    <link rel="stylesheet" href="styltrainnees.css">
</head>

<body>
<div class="div"><img src="./images/R.png" alt="" class="image">
    <u style="color: rgb(240, 186, 121);">  <h3 align ="center" style="color: cornsilk;">PLEASE FILL THIS FORM</h3></u>
    <div class="form1">
        <form action="insert.php" method="POST" align="center">
            <?php
             include_once('dp.php');
             ?>
        <br> <label for="name">ID :</label>
            <input type="number" name="id">
            </br>
            <br> <label for="name">First Name :</label>
            <input type="text" name="name">
            </br>
            <br> <label for="lname">Last name :</label>
            <input type="text" name="lname">
            </br>
             <label for="name">Gender :</label>
            <input type="radio" name="Gender" value="Male" class="radio" >Male <input type="radio" name="Gender" value="Female" class="radio" >Female
            
            <br> <label for="">Telephone :</label>
            <input type="number" name="Telephone">
            </br>
            <br> <label for="">Address :</label>
            <input type="text" name="Address">
            </br>
            

<br>
            <input type="submit" value="submit" name="submit">
            </br>



        </form>
    </div>

</body>

</html>