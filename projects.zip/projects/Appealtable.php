<?php
include_once('dp.php');

$a=$con->prepare('SELECT * FROM `appealtable`; ');
$a->execute();
$data=$a->fetchAll();

?>
<table border="1" align="center" cellpadding="20">
    <tr>
    <th>Trainee ID</th>
        <th>First name</th>
        <th>Last name</th>
        <th>Gender</th>
        <th>Appeals</th>
        
         

        
</tr>

   <tr>
     
     
   <?php foreach($data as $row):?>
    <tr>
    <td><?=$row['traineesid']?></td>
    <td><?=$row['fname']?></td>
    <td><?=$row['lname']?></td>
    <td><?=$row['Gender']?></td>
    <td><?=$row['Appeal']?></td>
    
</tr>
    <?php endforeach ?>

    
        