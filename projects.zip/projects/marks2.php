<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
   
</head>
<body>
    
</body>
</html>

<?php 
include_once('dp.php');
$a=$_POST['select_trainee'];
$b=$_POST['select_name'];
$c=$_POST['marks'];


if(isset($_POST['submit'])){
    $qry="select  fname FROM `trainees` where traineesid='$a'";
    $qry1="select  lname FROM `trainees` where traineesid='$a'";
$qry2="SELECT modulename FROM `module` where modulecode='$b'";


    $insert="INSERT INTO `marks`(`traineesid`, `modulecode`, `exammark`) VALUES ('$a','$b','$c')";
    $con->exec($insert);
}
$record=$con->prepare("$qry union $qry1");
$record->execute();
$data=$record->fetchAll();

$record2=$con->prepare("$qry2");
$record2->execute();
$data3=$record2->fetchAll();
?>
<table border="1" align="center" cellpadding="20">
    <tr>
        <th>First name</th>
        <th>Last name</th>
        <th>Module Name</th>
        <th>Marks</th>
         <th>Results</th>
         

        
</tr>

   <tr>
      <?php foreach($data as $rows):?>
        <td> <?=$rows['fname']?> <?php endforeach?></td>
      
      <?php foreach($data3 as $rows):?>
        <td> <?=$rows['modulename']?> <?php endforeach?></td>
     
     
        <?php echo"<td>".$c."</td>";
     if($c>55){
        
         echo "<td>"."Pass"."</td>";
         
     }
     else{
         echo"<td>"."Fail"."</td>";
        
     }
        ?>
        
       
</tr>
    
</table>


