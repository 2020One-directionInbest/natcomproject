<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="csstrans.css">
</head>
<body>
    <form action="trans.php" method="POST">
       
        <label for="name"> Product Name :</label>
        <select name="select_item" id="" required><br>
           <?php
           include_once('dp.php');
           $a=$con->prepare('select * from itemsregistration');
           $b=$con->prepare('select * from customer');
           $a->execute();
           $b->execute();
           $data=$a->fetchAll();
           $bdata=$b->fetchAll(); ?>
           <option>select Items</option>
           <?php foreach($data as $row):?>
           <option value="<?=$row['id_items']?>"><?=$row['Items_name']?></option>
           <?php endforeach?>
        </select></br>
        <label for="">Quantity</label>
        <input type="number" name="num"><br>
        <label for="">Customer Name</label>
        <select name="select_name" id=""><br>
        <option>select name</option>
        <?php foreach($bdata as $row):?>
        <option value="<?=$row['C_id']?>"><?=$row['Customer_Name']?></option>
        <?php endforeach?>
        </select></br>
        <input type="submit" name="submit" value="saveDatabase">
        
    </form>
</body>
</html>