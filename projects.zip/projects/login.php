<?php
require_once('dp.php');
session_start();
if(isset($_POST['login'])){
    $u=$_POST['username'];
    $p=$_POST['password'];
    $smt1=$con->prepare( "SELECT * FROM `user` WHERE `username`='$u'AND`password`='$p'");
    $smt1->execute();
    $row=$smt1->fetch(PDO::FETCH_ASSOC);
    if($row>0){
        $_SESSION['id']=$row['username'];
        echo"<script>alert('Login Successfully!')</script>";
        echo"<script>window.location='index2.php'</script>";
        
    }
    else{
        echo"<script>alert('Failed!Try again')</script>";
        echo"<script>window.location='index.php'</script>";
    }
}
?>