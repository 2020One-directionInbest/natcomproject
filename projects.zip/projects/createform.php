<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="styl2.css">
</head>
<body>
<div class="div"><img src="./images/R.png" alt="" class="image">
    <form action="insertcreate.php" method="POST">
    Insert ID
        <input type="text" name="ID"><br></br>
        Create username
        <input type="text" name="username"><br></br>
        Create password
        <input type="password" name="password"><br>
       
         User Type
        <input type="text" name="usertype"><br></br>
        <input type="submit" name="submit" class="sub"><br></br>

    </form>
</body>
</html>