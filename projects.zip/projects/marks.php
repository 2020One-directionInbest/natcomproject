<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style3.css">
</head>
<body>
<div class="div"><img src="./images/R.png" alt="" class="image">
    <form action="marks2.php" method="POST">
<label for=""> Trainee ID</label>
<select name="select_trainee" id="" required>
           <?php
           include_once('dp.php');
           $a=$con->prepare('SELECT * FROM `trainees`');
           $b=$con->prepare('select * from module');
           $a->execute();
           $b->execute();
           $data=$a->fetchAll();
           $bdata=$b->fetchAll(); ?>
           <option>Trainee ID</option>
           <?php foreach($data as $row):?>
           <option value="<?=$row['traineesid']?>"><?=$row['traineesid']?></option>
           <?php endforeach?>
        </select></br>
        
        
        <label for="">Module Name</label>
        <select name="select_name" id=""><br>
        <option>select Module</option>
        <?php foreach($bdata as $row):?>
        <option value="<?=$row['modulecode']?>"><?=$row['modulename']?></option>
        <?php endforeach?>
        </select></br>
        <label for="">Marks</label>
        <input type="number" name="marks"><br></br>
        <input type="submit" name="submit" value="Submit" id="sub">
        
    </form>
</body>

</html>