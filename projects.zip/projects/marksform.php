<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="styl2.css">
</head>
<body>

<div class="div"><img src="./images/R.png" alt="" class="image">
<u style="color: rgb(240, 186, 121);">  <h3 align ="center" style="color: cornsilk;">VIEW MARKS</h3></u>

<form action="marks3.php" method="POST">
    <br>
   Trainee id
    <input type="text" name="traineeid"></br>
    <br>
    Module code
    <input type="text" name="modulecode"></br>
    <br>
   
    <input type="text" name="marks" hidden></br>
    <br>
  
    <input type="submit" value="view marks" name="login" class="sub"><br>
  
</form>
</div>
</body>

</html>