<?php 
include_once('dp.php');
$a=$_POST['traineeid'];
$b=$_POST['modulecode'];
$c=$_POST['marks'];

if(isset($_POST['login'])){
    
    $qry1="select  modulecode FROM `module` where modulecode='$b'";
    $qry2="select  exammark FROM `marks` where traineesid ='$a'";
    $qry3="select  fname FROM `trainees` where traineesid='$a'";
    $qry4="select  lname FROM `trainees` where traineesid='$a'";
    
}


$record1=$con->prepare("$qry1");
$record1->execute();
$data1=$record1->fetchAll();

$record3=$con->prepare("$qry2");
$record3->execute();
$data2=$record3->fetchAll();

$record4=$con->prepare("$qry3 union $qry4");
$record4->execute();
$data3=$record4->fetchAll();
?>
<table border="1" align="center" cellpadding="20">
    <tr>
        <th>First name</th>
        <th>Last name</th>
        <th>Module Code</th>
        <th>Marks</th>
        <th>Result</th>
         
         

        
</tr>

   <tr>
      <?php foreach($data3 as $rows):?>
        <td> <?=$rows['fname']?> <?php endforeach?></td>
        <?php foreach($data1 as $rows):?>

        <td> <?=$rows['modulecode']?> <?php endforeach?></td>

        <?php foreach($data2 as $rows):?>
        <td> <?=$rows['exammark']?> <?php endforeach?></td>
        
        <?php 
     if($c<55){
        
         echo "<td>"."Pass"."</td>";
         
     }
     else{
         echo"<td>"."Fail"."</td>";
        
     }?>
        </table>
        <a href="Appealform.php">fill this form to appeal</a>