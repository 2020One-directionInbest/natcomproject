<?php

include_once('dp.php');

if(isset($_POST['submit'])){
    $f=$_POST['id'];
$a=$_POST['name'];
$b=$_POST['lname'];
$c=$_POST['Gender'];
$d=$_POST['appeal'];
$date= date("d-m-y");

$q="INSERT INTO `appealtable`(`traineesid`, `fname`, `lname`, `Gender`, `Appeal`, `Action`) VALUES ('$f','$a','$b','$c','$d','$date')";
$con->exec($q);

}

?>
</html>