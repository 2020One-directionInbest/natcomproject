<html>
    <head>
        <title>
            Invoice
        </title>
        <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    
        <link rel="stylesheet" href="cssindexpag.css">
  
    </head>
    <style>
.dropbtn {
  background-color: #04AA6D;
  color: white;
  padding: 16px;
  font-size: 16px;
  border: none;
  border-radius:10px;
  border:1px solid white;
}

.dropdown {
  position: relative;
  display: inline-block;
  margin-left:1080px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;

}

.dropdown-content a {
  color: #04AA6D;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #ddd;}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {background-color: #3e8e41;}
h1{
  animation: 5s title cubic-bezier(0.455, 0.03, 0.515, 0.955) alternate infinite;
  margin-left:30px;
  color:rgb(240, 240, 230);
}
h2{
  animation: 5s title cubic-bezier(0.455, 0.03, 0.515, 0.955) alternate infinite;
  margin-left:600px;
  color:rgb(240, 240, 230);
}
}
.nav-link{
  color:#04AA6D;
  background-color: #f1f1f1;
}

@keyframes title {
    0%{filter:blur(1px);letter-spacing:0.1em;}
    25%{filter:blur(2px);letter-spacing:0.4em;}
    50%{letter-spacing:0.67em;}
    75%{letter-spacing:0.4em;}  
}
.img{
  animation:anim  5s alternate 0s cubic-bezier(0.455, 0.03, 0.515, 0.955)  infinite;
}
body{
    background-image: linear-gradient(to right ,rgb(174, 199, 240),rgb(22, 169, 214));
}
.about{
   background-image: linear-gradient(to right ,rgb(240, 240, 230),rgb(72, 184, 87));
}
@keyframes anim {
        0%{transform: rotate(20deg);}

       50%{transform: rotate(5deg);}
       100%{transform: rotate(360deg);}}

       .cont{
         display:flex;
         flex-direction:row;
         height:400px;
       }
       .carousel{
         width:50%;
       }
</style>
</head>

   <h1>Natcom Training Center</h1>

   <div class="con">
          <nav class="navbar navbar-expand-lg navbar-light bg-light">
          
            <img src="./images/R.png" alt="" height="40" width="90" class="img">
           
           
           <div>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
              <ul class="navbar-nav">
                <li class="nav-item active">
                  <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item active">
                  <a class="nav-link" href="#about">About Us<span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item active">
                  <a class="nav-link" href="#courses">Our services<span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item active">
                  <a class="nav-link" href="#contact">Contact Us<span class="sr-only">(current)</span></a>
                </li>
</div>
                <div class="dropdown">
                
  <button class="dropbtn">Log in</button>
  <div class="dropdown-content">
    
    <a href="index.php">Log in as Admin</a>
    <a href="marksform.php">Log in as Trainee</a>
  </div>
</div>
</nav>
      </div>
           
   <div class="cont">


           <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
              <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
              <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
              <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner">
              <div class="carousel-item active">
                <img class="d-block w-100" src="./images/capture1.png" alt="First slide" height="400" >
              </div>
              <div class="carousel-item">
                <img class="d-block w-100" src="./images/capture2.jfif" alt="Second slide" height="400" >
              </div>
              <div class="carousel-item">
                <img class="d-block w-100" src="./images/capture3.png" alt="Third slide" height="400" >
              </div>
            </div>
            <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
              <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
              <span class="carousel-control-next-icon" aria-hidden="true"></span>
              <span class="sr-only">Next</span>
            </a>
          </div>
      

          <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
              <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
              <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
              <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner">
              <div class="carousel-item active">
                <img class="d-block w-100" src="./images/GIF1.gif" alt="First slide" height="400" width="200">
              </div>
              <div class="carousel-item">
                <img class="d-block w-100" src="./images/wallpaper.gif" alt="Second slide" height="400" width="200" >
              </div>
              <div class="carousel-item">
                <img class="d-block w-100" src="./images/gif2.gif" alt="Third slide" height="400" width="200" >
              </div>
            </div>
            <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
              <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
              <span class="carousel-control-next-icon" aria-hidden="true"></span>
              <span class="sr-only">Next</span>
            </a>
          </div>

        </div>
      
      <br>
    
        <h2>About us</h2>
        <div class="about">
       
         <a name="about"> N@TCOM is a training firm in Rwanda, which focuses on ―bridging the digital divide and certifying the future by assisting individual graduates to attain personal, career and life goals through hands on skills and globally recognized certifications. N@tcom empowers university/college graduates to advance their skills and technical experience required by employers; provide internationally recognized IT courses from beginner to advanced and to build the entrepreneurship models among youths to create their own-jobs.

N@TCOM gets down into the process of rebuilding the pillars of businesses through certifying and equipping professionals who need to upgrade their IT-skills and knowledge, by providing technical experience required in businesses today and also our trainee’s benefits from our best practices of the “Learn by doing Model”
         </a></div>
         <br>
         <h2>Our services</h2>
         <div class="service">
         <a name="courses"> N@tcom Services Ltd facilitates the certifications of the trainees by creating the enabling environment for them so that they do not spend much time gathering the requirement themselves. However, N@tcom Services Ltd will sometimes provide certificates after the training while the trainees are waiting for the international providers. N@tcom Services Ltd ensures that there are strong partnerships with the local and international certification companies and organizations so that the trainees can get the maximum from the course which is being offered.

Our most popular training courses

Entrepreneurship and Mentorship (Support startups with Business-skills)
Cisco Networking (ICND 1&2, CCNA R&S, CCNA-Security, CCNP)
Oracle (OCA, OCP, DB 12C-Essential, builder, Audit vault, Security, etc
EA (Enterprise Architecture with TOGAF Training& Certification
Microsoft (MTA, MCTS, MCSA/MCSE) LINUX, ICDL)
Cyber Security (CEH, PEH, ISSO, ISMS, EC-COUNCIL, CISA, ISAKA)
Networking & System Administration (Comptia A+, N+, MCTS)
CODING, Programming and Mobile-Application products and customized training course combined with soft skills (Communication, Customer Care, Business meeting skills, Time Management, Interviewing skills etc.
IT Professional Training Certification

Microsoft Certified Solution Expert 2012
Microsoft Certified Solution Expert2013
Microsoft Technology Associate (MTA)
Microsoft Certified Technology Specialist (MCTS)
International Computer Driving License (ICDL)
CompTIA Strata
CompTiA A+
CompTiA N+
Advanced Professional Courses

Cisco Certified Network Associate (CCNA)
Cisco Certified Network Professional (CCNP)
Oracle OCA, OCP,Solaris
Linux and Red Hat
Microsoft Certified Solutions Expert gaf
Microsoft Certified Solutions Expert(MCSE)
ITIL 2011-Life Cycle Modules
ITIL 2011-Intermediate Courses
Microsoft Office-Excel –Word -Power Point
         </a></div>
         <h2>Contact us</h2>
         <div class="about">
         <a name="contact"> Lorem ipsum dolor sit amet consectetur adipisicing elit. Laudantium mollitia architecto eveniet veritatis nobis animi consequatur est ipsam magnam modi soluta ad, laborum iure dolorem cupiditate veniam debitis esse blanditiis.
           Lorem ipsum, dolor sit amet consectetur adipisicing elit. A ex ipsum, animi vitae odio quaerat eum sapiente quo ipsa sint laboriosam nisi quod at perspiciatis inventore reprehenderit. Alias, nemo veniam?
           Lorem ipsum dolor sit amet consectetur adipisicing elit. Alias rerum laborum veniam qui recusandae a doloremque necessitatibus molestiae! Consectetur repellendus debitis eius dicta unde totam, dolor ab? Aperiam, iste eveniet.
           
         </a></div>

        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>

    </body>
</html>