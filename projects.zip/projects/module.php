<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="styl2.css">
</head>
<body>
<div class="div"><img src="./images/R.png" alt="" class="image">
    <form action="" method="post">
    Insert Module code
        <input type="num" name="code"><br></br>
       Module name
        <input type="text" name="name"><br></br>
        <input type="submit" name="submit"><br></br>
    </form>
    
</body>
<?php
include_once('dp.php');
if(isset($_POST['submit'])){
    
$a=$_POST['code'];
$b=$_POST['name'];

$q="INSERT INTO `module`(`modulecode`, `modulename`) VALUES ('$a','$b')";
$con->exec($q);
echo"<script>alert('created Successfully!')</script>";
echo"<script>window.location='index2.php'</script>";
} ?>
</html>